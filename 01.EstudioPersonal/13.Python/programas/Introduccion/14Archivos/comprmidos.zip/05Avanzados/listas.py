numero = [1, 2, 3]
letras = ["a", "b", "c"]
matriz = [[2, 3, 4], ["b", "c", "d"]]
rango = list(range(1, 11))
strings = list("Ramiro Tello")

print(matriz)
