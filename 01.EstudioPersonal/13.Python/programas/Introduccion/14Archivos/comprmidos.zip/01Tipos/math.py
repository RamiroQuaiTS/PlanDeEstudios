import math

ceil = math.ceil(1.1)
print(ceil)
print(math.ceil(1.1))
print(math.floor(1.99999))
print(math.isnan(23))
print(math.pow(10, 3))
