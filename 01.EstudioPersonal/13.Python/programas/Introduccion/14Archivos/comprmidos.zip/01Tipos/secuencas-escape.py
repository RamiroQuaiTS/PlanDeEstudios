# Para poner comillas o caractere especiales se usa \
# \n hace un brinco de linea
curso = "Curso de \n\"PYTHON\""
print(curso)
