for j in range(3):
    for k in range(2):
        print(f"{j}-{k}")
