edad = int(input("Captura edad: "))

mensaje = "es mayor" if edad >= 18 else "es menor"

print(mensaje)

if edad == 18:
    print("todo bien con el if ya que capturo 18")
else:
    print("todo mal con el if ya que no se capturo 18")
