for numero in range(5):
    print(numero, numero * 'hola ')

buscar = 50
for numero in range(20):
    print(numero)
    if numero == buscar:
        print("Se encontró")
        break
else:
    print("no se encontró")

for char in "Ramiro Tello Santoscoy":
    print(char)
