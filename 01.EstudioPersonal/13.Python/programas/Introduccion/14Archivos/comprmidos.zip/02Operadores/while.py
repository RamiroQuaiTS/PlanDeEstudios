# numero = 1
# while numero < 10:
#     print(numero)
#     numero += 1

comando = ""

while comando.capitalize() != "Salir":
    comando = input("$ ")
    print(comando)
