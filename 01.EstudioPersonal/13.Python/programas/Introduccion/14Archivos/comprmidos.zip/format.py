Juego = "Metal Gear"
d = 1
b = 33
