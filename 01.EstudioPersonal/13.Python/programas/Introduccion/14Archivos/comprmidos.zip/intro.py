"""Introducción a python."""
import sys

print("Hola mundo!" * 2)
print("prueba")
print(sys.version)
