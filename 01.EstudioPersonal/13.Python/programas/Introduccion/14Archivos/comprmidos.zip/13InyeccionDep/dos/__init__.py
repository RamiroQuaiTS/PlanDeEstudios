def init(bd, api, **_):
    print(f"Soy modulo dos: {api} {bd}")
