def init(bd, **_):
    print(f"soy modulo uno y recibo {bd}")
