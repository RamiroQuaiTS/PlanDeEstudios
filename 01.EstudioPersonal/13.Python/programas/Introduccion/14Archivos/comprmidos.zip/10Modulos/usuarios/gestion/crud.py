def guardar():
    print("Guardando")


def consultar():
    print("Consultando")


def actualizar():
    print("Actualizando")
