from usuarios.impuestos.utilidades import pagarImpuestos
import usuarios

pagarImpuestos()
print(dir(usuarios))
